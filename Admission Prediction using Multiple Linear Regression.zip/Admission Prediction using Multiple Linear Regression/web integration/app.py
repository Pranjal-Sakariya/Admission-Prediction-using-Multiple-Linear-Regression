import flask
import pickle
import pandas as pd

# Use pickle to load in the pre-trained model.
with open(f'model/model.pkl', 'rb') as f:
    model = pickle.load(f)

app = flask.Flask(__name__, template_folder='templates')


@app.route('/', methods=['GET', 'POST'])
def main():
    if flask.request.method == 'GET':
        return (flask.render_template('main.html'))
    if flask.request.method == 'POST':
        gre = int(flask.request.form['gre'])
        toefl = int(flask.request.form['toefl'])
        university = float(flask.request.form['university_rating'])
        sop = float(flask.request.form['sop'])
        lor = float(flask.request.form['lor'])
        cgpa = float(flask.request.form['cgpa'])
        research = int(flask.request.form['research'])
        input_variables = pd.DataFrame([[gre,toefl,university,sop,lor,cgpa,research]], columns=['GRE Score', 'TOEFL Score', 'University Rating','SOP','LOR','CGPA','Research'], dtype=float)
        prediction = model.predict(input_variables)[0]
        prediction = format(float(prediction*100),'.2f')
        return flask.render_template('main.html',result=prediction)

if __name__ == '__main__':
    app.run()